#ifdef WIN32
#include "../stdafx.h"
#endif

#include "parser.h"

Parser::Parser(const string& s) : filename(s)
{
}
Parser::~Parser() {}
