#!/bin/sh
# http://trulsjor.wordpress.com/2009/07/31/how-to-send-text-to-the-display-on-squeezebox/
MSG=$1
if [ $# -lt 1 ] ; then
echo Skriv en melding
read MSG
fi
MSG=$(echo $MSG|sed 's/ /%20/g')
(
echo 00:04:20:07:3d:00 show line2:$MSG font:huge duration:15
sleep 1
echo exit
) | telnet 192.168.0.196 9090
exit

