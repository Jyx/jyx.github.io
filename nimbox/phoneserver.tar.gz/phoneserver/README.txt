Phoneserver

1. Vad �r detta?

Ett perl-script som hanterar inkommande samtal med hj�lp av
en ansluten nummerpresentat�r (t.ex. NIM) och ett gammalt
analogt seriellt modem.

Funktioner:
  - Svart lista f�r utvalda nummer i telefonboken
    N�r ett svartlistat nummer ringer s� kopplas detta ner direkt
   (mha modemet) - detta innan n�gon ansluten telefon hinner
    ringa. 
    Eftersom jag inte har ett voicemodem blir detta tyv�rr en 
    "tyst nedkoppling", dvs modemet lyfter luren och l�gger p� direkt.
    Med ett voicemodem skulle man kunna l�gga till b�de meddelande
    och telefonsvararfunktion.

  - Inst�llbar hantering av anonyma nummer
    (till�t/till�t under dagtid/koppla bort)

  - M�jlighet till vit lista (dvs att bara angivna nummer till�ts
    under vissa tidsperioder)

  - Distribution av CallerID till YAC-klienter

  - En f�rs�k att sl� upp nummer p� hitta.se eller/och eniro.se om de inte 
    finns i telefonboken. 

  - loggning 

Allt �r konfigurerbart - se den kommenterade initieringsfilen (phoneserver.ini)

Telefonboken (phonebook.txt) inneh�ller nummer man vill l�gga in, �vers�ttning till
namn och en indikering om numret �ven skall l�ggas till p� vit eller svart lista.
Se kommentarerna i phonebook.txt f�r hur detta anges.

2. Hur ansluter man?

Fysiskt kopplas nummerpresentat�ren (NIM) till datorn via en serieport och modemet till en annan.
Det vanligaste f�r analoga modem �r att �ven "inbyggda" (dvs t.ex. PCI-kort) eller USB-anslutna modem
har ett serieinterface och allts� fungerar med Phoneserver.

B�da enheterna kopplas in till telejacket (se �ven punkt 5 nedan).

Man m�ste ange serieportarna i initieringsfilen (phoneserver.ini). Det mesta i denna fil har
default-v�rden, men portarna �r en sak som m�ste anges.
P� Windows-system �r det t.ex COM1 och COM3, och p� unixsystem kanske /dev/ttyS0 och /dev/modem. 

3. Hur k�r man?

B�st �r att installera perl; 
(h�mtas gratis fr�n http://www.activestate.com/store/productdetail.aspx?prdGuid=81fbce82-6bd5-49bc-a915-08d58c2648ca)

Scriptet anv�nder modulerna LWP::Simple, Win32::API och Win32::SerialPort (p� Windows) alternativt
LWP::Simple och Device::SerialPort f�r andra OS. 
Dessa kan installeras enklast genom verktyget ppm (Perl Package Manager, installeras med perl). Skriv ppm i ett 
kommandof�nster f�r att starta ppm med grafikf�nster.
Modulerna kan ocks� installeras manuellt fr�n CPAN (Comprehensive Perl Archive Network, http://www.cpan.org/)

D�refter �r det bara att dubbelklicka p� phoneserver.pl. 
Alternativt kan man ge kommandot 'perl -w phoneserver.pl'i ett kommendof�nster. Man m�ste d� st� 
i samma bibliotek phoneserver.pl finns. Det sistn�mnda s�ttet �r att f�redra
om n�got g�r fel vid uppstart, eftersom man d� har kvar alla utskrifter.

Ett alternativt s�tt att k�ra f�r windowsanv�ndare som inte vill installera perl (varf�r???)
�r att k�ra phoneserver.exe i st�llet. Detta �r egentligen ingen kompilerad fil utan �r en
sammanpackning av scriptet + alla moduler som beh�vs. 
Fungerar i �vrigt som en vanlig .exe-fil i windows. K�r man perl s� kan man ta bort phoneserver.exe.

Gl�m inte att uppdatera konfigureringsfil (phoneserver.ini) och telefonbok (phonebook.txt)
s� att programmet uppf�r sig som du vill.

4. Varf�r perl?

D�rf�r att:
- Fungerar p� en m�ngd olika plattformar och OS
- Kompetent och snabbt att skriva sm� script i; man m�ste allts� �nd� ha det installerat
  f�r att kunna g�ra n�got vettigt p� datorn ;-)

5. Diverse
- "Jag f�r inget nummer fr�n NIM n�r jag kopplar in b�de modem och NIM i samma telejack"
  NIM kan tydligen vara k�nslig. Jag har sj�lv ett dubbeljack med NIM i ett uttag och 
  modemet i det andra. Fungerar perfekt.
  (Motsvarande
  http://www.telia.se/privat/katalog/VisaProdukt.do?productRef=/privat/produkter_tjanster/fasttelefoni/produkterocherbjudanden/tillbehor/jackdubbelt_utanpaliggandeisvit.600010880.product@SE_TELIA
  )

- "Utskrifter kommer i ett DOS-f�nster - n�r kommer ett snyggare GUI?"
  Inte i n�rtid. Detta �r fullt tillr�ckligt f�r mig sj�lv.
  Men om n�gon vill g�ra en GUI-modul l�gger jag g�rna till denna.

- "Telefonsvararfunktionalitet?"
  Borde vara l�tt att l�gga in, men jag har sj�lv inget voice-modem och kommer inte
  att utveckal detta.
  Vill man ha en fullst�ndig telefonv�xel kanske man skall titta p� asterisk.
