#!/usr/bin/perl -w
#
# Phoneserver
# (c) Jan Nilsson 2008-
# This code is released under the GNU General Public License (GPL) Version 2
#
# The following parts of the code is specific for the NIM Caller ID device
# and must be updated if another device is used:
# - the "test_CID_communication" subroutine
# - the format of the callerID (i.e. the "$cid = " lines) in the main loop
#
use strict;
use threads;
use threads::shared;
use Thread;
use Thread::Semaphore;
use Thread::Queue;
use IO::Socket; 
use LWP::Simple;
use Device::SerialPort;

my $semaphore :shared;
my $queue :shared;
my $numbersent :shared;
$numbersent = 0;

my ($answ, $modemport, $numpresport, $cid, @yaclist, $logfile, $configname, $modem_ob, $numpres_ob);
my ($OS_win, $nm_start_hr, $nm_start_min, $nm_stop_hr,$nm_stop_min,$log_accepted_calls, $log_verbose);
my ($announce_disconnection,$use_nightmode);
my %configtable = ();
my %blacklist = ();
my %whitelist = ();
my %phonebook = ();
my $nightmode = 0;
my $use_whitelist = 0;
my $is_anon = 0;
my $thr;

$queue = Thread::Queue->new();
$semaphore = Thread::Semaphore->new();

################################################################################
# Sub routines
################################################################################
sub get_the_time {
	my ($second, $minute, $hour, $dayOfMonth, $month, $yearOffset, $dayOfWeek, $dayOfYear, $daylightSavings) = localtime();
	my $year = 1900 + $yearOffset;
	my $theTime = sprintf("%04u-%02u-%02u %02u:%02u:%02u",$year,$month+1,$dayOfMonth,$hour,$minute,$second);
	return $theTime;
}

sub send_sbmsg {
	print "Thread started\n";
	my $DEBUG = 1;

	while (my $msg = $queue->dequeue()) { 
		# Always send firsta message, i.e. phone number only.
		print "Number only: Popped $msg off the queue\n" if $DEBUG;
		my $sbmsg = "./sbmsg_short.sh \"$msg\"";
		print "$sbmsg\n" if $DEBUG;
		system($sbmsg);
		sleep 6;

		$semaphore->down();
		my $copy_numbersent = $numbersent;
		$semaphore->up();

		# Next check if we have name also, then we should resend that.
		if ($copy_numbersent == 2) {
			$msg = $queue->dequeue();
			print "Name also: Popped $msg off the queue\n" if $DEBUG;
			my $sbmsg = "./sbmsg.sh \"$msg\"";
			print "$sbmsg\n" if $DEBUG;
			system($sbmsg);
		} else { # Otherwise, send same message again.
			print "Resend Number only: $msg\n" if $DEBUG;
			my $sbmsg = "./sbmsg.sh \"$msg\"";
			print "$sbmsg\n" if $DEBUG;
			system($sbmsg);
		}

		$semaphore->down();
		$numbersent = 0;
		$semaphore->up();
	} 
}

my $starttime = get_the_time();
$thr = new Thread \&send_sbmsg;

sub monitor_serial
{
	my($com)=@_;

	while(1)
	{
		my $buf = com_readbytes($com, 60000, 1);
		if (defined($buf) and (length($buf)) > 0)
		{
			while(1) {
				my $morebuf = com_readbytes($com,100,5);
				$buf .= $morebuf 
					if ($morebuf);
				if(! $morebuf) {
					$buf =~ tr/a-zA-Z0-9:; //cd;
					return $buf;};
			}
		}
		update_nightmode_status();
	}
}

sub com_readbytes {
	my($com,$timeout,$bytesleft)=@_;

	$com->read_const_time($timeout);
	my($rb,$data)=$com->read($bytesleft);
	return $data;
}

sub init_nightmode_status {
	my ($curhr, $curmin,$i,%nm_hrs);

	$use_nightmode = 1;
	if($configtable{"nightmode_start"}) {
		($nm_start_hr,$nm_start_min) = split(":",$configtable{"nightmode_start"});
	} else {
		print "WARNING - start time for nightmode not given - deactivated\n";
		$use_nightmode = 0;
	}
	if($configtable{"nightmode_stop"}) {
		($nm_stop_hr,$nm_stop_min) = split(":",$configtable{"nightmode_stop"});
	} else {
		print "WARNING - stop time for nightmode not given - deactivated\n";
		$use_nightmode = 0;
	}

	if($configtable{"nightmode_start"} eq $configtable{"nightmode_stop"}) {
		$nightmode = 1;
		print  "Nightmode constantly active\n";
		($log_verbose) && print LOGFILE "Nightmode constantly active\n";
		return 1;
	}

	if($use_nightmode) {
		($curhr, $curmin) = (split("[ :]",get_the_time())) [-3,-2];
		$nightmode = 0;
		$i = $nm_start_hr;
		$i++;
		if($i == 24) {$i = 0;}
		do {
			if($i != $nm_stop_hr) {$nm_hrs{sprintf("%02u",$i)} = 1;}
			$i++;
			if($i == 24) {$i = 0;}
		} until ($i == $nm_stop_hr);

		if(exists $nm_hrs{$curhr}) {
			$nightmode = 1;
		} else {
			if(($curhr == $nm_start_hr) && ($curmin >= $nm_start_min)) {$nightmode = 1;}
			if(($curhr == $nm_stop_hr) && ($curmin >= $nm_stop_min)) {$nightmode = 0;}
		}

		printf "Nightmode active between %s and %s - ",$configtable{"nightmode_start"},$configtable{"nightmode_stop"};
		($log_verbose) && printf LOGFILE "Nightmode active between %s and %s - ",$configtable{"nightmode_start"},$configtable{"nightmode_stop"};
		if($nightmode) {
			print "nightmode activate at startup\n";
			($log_verbose) && print LOGFILE "nightmode activate at startup\n";		
		} else {
			print "normal mode active at startup\n";
			($log_verbose) && print LOGFILE "normal mode active at startup\n";
		}
	}
}

sub update_nightmode_status {
	my ($curhr, $curmin);

	if($configtable{"nightmode_start"} eq $configtable{"nightmode_stop"}) { # constant nightmode
		return 1;
	}
	($curhr, $curmin) = (split("[ :]",get_the_time())) [-3,-2];
	if($use_nightmode) {
		if($nightmode) {
			if(($curhr == $nm_stop_hr) && ($curmin >= $nm_stop_min)) {
				printf "Switching to normal mode at %s\n",get_the_time();
				($log_verbose) && printf LOGFILE "Switching to normal mode at %s\n",get_the_time();
				$nightmode = 0;
			}      
		} else {
			if(($curhr == $nm_start_hr) && ($curmin >= $nm_start_min)) {
				printf "Switching to nightmode at %s\n",get_the_time();
				($log_verbose) && printf LOGFILE "Switching to nightmode at %s\n",get_the_time();
				$nightmode = 1;
			}
		}       
	}
}

sub handle_call_normal_mode
{
	my $checkinet;

	if(exists $blacklist{$cid}) {	# CID is blacklisted
		if(exists $phonebook{$cid}) {
			$cid = $phonebook{$cid} . " (" . $cid . ")";
		}
		#disconnect_call();
		($announce_disconnection) && send_YAC("$cid disconnected\n");
	} elsif(! $is_anon) {	# CID exists
		$checkinet = 0;
		if(exists $phonebook{$cid}) {
			$cid = $phonebook{$cid} . " (" . $cid . ")";
		} else {
			$checkinet = 1;
		}
		printf "Incoming call from $cid allowed at %s\n",get_the_time();
		($log_accepted_calls) && printf LOGFILE "%s: Incoming call from $cid allowed\n",get_the_time();
		send_YAC("$cid\n");
		$semaphore->down();
		$numbersent = 1;
		$semaphore->up();
		if(($checkinet) && ($configtable{"internet_lookup"})) {
			# Done after initial presentation since this could take some time
			if(lookup_number()) {
				# Succeeded - send updated information
				printf "Internet lookup ok: Incoming call from $cid allowed\n";
				($log_accepted_calls) && printf LOGFILE "%s:Internet lookup ok:  Incoming call from $cid allowed\n",get_the_time();
				send_YAC("$cid\n");       	
				$semaphore->down();
				$numbersent = 2;
				$semaphore->up();
			} else {
				print "Internet lookup not successful\n";
				(($log_verbose) && ($log_accepted_calls)) && print LOGFILE "Internet lookup not successful\n";       	
			}
		}
	} else {		# Anonymous
		if($configtable{"disconnect_anonymous"} eq "yes") {
			#disconnect_call();
			($announce_disconnection) && send_YAC("$cid disconnected\n");
		} elsif (($configtable{"disconnect_anonymous"} eq "night") && ($nightmode)) {
			#disconnect_call();
			($announce_disconnection) && send_YAC("$cid disconnected\n");    	
		} else {
			printf "Incoming call from $cid allowed at %s\n",get_the_time();
			($log_accepted_calls) && printf LOGFILE "%s: Incoming call from $cid allowed\n",get_the_time();
			send_YAC("$cid\n");
			$semaphore->down();
			$numbersent = 1;
			$semaphore->up();
		}
	}
}

sub handle_call_whitelist
{
	if(exists $whitelist{$cid}) {
		if(exists $phonebook{$cid}) {
			$cid = $phonebook{$cid} . " (" . $cid . ")";
		}
		printf "Incoming call from $cid allowed at %s\n",get_the_time();
		($log_accepted_calls) && printf LOGFILE "%s: Incoming call from $cid allowed\n",get_the_time();
		send_YAC("$cid\n");
	} else {
		if(exists $phonebook{$cid}) {
			$cid = $phonebook{$cid} . " (" . $cid . ")";
		}
#disconnect_call();
		($announce_disconnection) && send_YAC("$cid disconnected\n");
	} 
}


sub disconnect_call {
#$modem_ob->write("ATH1\r");
	sleep 1;
#$modem_ob->write("ATH0\r");
	printf "Incoming call from $cid disconnected at %s\n",get_the_time();
	printf LOGFILE "%s: Disconnected call from $cid\n",get_the_time();
}

sub write_OK{
	my($com,$command)=@_;

	$com->write($command);
	my $resp = monitor_serial($com);
	if($resp ne "OK"){
		fatal ( "Command $command to port " . $com->alias . " returned '$resp' at " . get_the_time());
	}
	return $resp;
}

sub read_config{
	my ($configname) = @_;
	my ($confline, $confindex, $configvalue, $i, $yacstr);


	open(CONFIGFILE,$configname) || fatal("Cannot open config file '$configname': $!");
	while( defined($confline = <CONFIGFILE>)) {
		chomp($confline);
		($confindex = $confline) =~ s/\W.*//;
		if($confindex) {	# parameter found
			$configvalue = (split(/\s+/,$confline))[1];
			$configtable{$confindex} = $configvalue;
		}
	}
	close(CONFIGFILE) || fatal("Cannot close config file: $!");

# Some default values if omitted in config file
	$configtable{"logdir"} = "log" unless exists $configtable{"logdir"};
	$configtable{"logbasename"} = "pslog_" unless exists $configtable{"logbasename"};
	$configtable{"use_whitelist"} = 0 unless exists $configtable{"use_whitelist"};
	$configtable{"disconnect_anonymous"} = "no" unless exists $configtable{"disconnect_anonymous"};
	$configtable{"phonebook"} = "phonebook.txt" unless exists $configtable{"phonebook"};
	$configtable{"internet_lookup"} = 0 unless exists $configtable{"internet_lookup"};
	$configtable{"save_internet_lookup"} = 0 unless exists $configtable{"save_internet_lookup"};
	$configtable{"modem_speed"} = 9600 unless exists $configtable{"modem_speed"};
	$configtable{"modem_parity"} = "none" unless exists $configtable{"modem_parity"};
	$configtable{"modem_databits"} = 8 unless exists $configtable{"modem_databits"};
	$configtable{"modem_stopbits"} = 1 unless exists $configtable{"modem_stopbits"};
	$configtable{"modem_handshake"} = "rts" unless exists $configtable{"modem_handshake"};
	$configtable{"cid_speed"} = 9600 unless exists $configtable{"cid_speed"};
	$configtable{"cid_parity"} = "none" unless exists $configtable{"cid_parity"};
	$configtable{"cid_databits"} = 8 unless exists $configtable{"cid_databits"};
	$configtable{"cid_stopbits"} = 1 unless exists $configtable{"cid_stopbits"};
	$configtable{"cid_handshake"} = "rts" unless exists $configtable{"cid_handshake"};
	$configtable{"No_of_YAC_clients"} = 0 unless exists $configtable{"No_of_YAC_clients"};
	$configtable{"log_accepted_calls"} = 1 unless exists $configtable{"log_accepted_calls"};
	$configtable{"announce_disconnection"} = 1 unless exists $configtable{"announce_disconnection"};
	$configtable{"internet_search_engine"} = 0 unless exists $configtable{"internet_search_engine"};
	$configtable{"log_verbose"} = 1 unless exists $configtable{"log_verbose"};

# Some parsing...

	if(($configtable{"use_whitelist"} == 1) || ($configtable{"disconnect_anonymous"} eq "night")) {
		$use_nightmode = 1;
	} else {
		$use_nightmode = 0;
	}
	for($i=0;$i < $configtable{"No_of_YAC_clients"};$i++) {
		$yacstr = "YAC_client_$i";
		if(exists $configtable{$yacstr}) {
			$yaclist[$i] = $configtable{$yacstr};
		} else {
			fatal($configtable{"No_of_YAC_clients"} . " YAC clients defined, but $yacstr not found in configuration file");
		}
	}  	
	$announce_disconnection = $configtable{"announce_disconnection"};
	$log_accepted_calls = $configtable{"log_accepted_calls"};
	$log_verbose = $configtable{"log_verbose"};
}

sub read_phonebook{
	my ($confline, $confindex, $configvalue, $configcategory);

	print "Reading phonebook: ";
	open(PHONEBFILE,$configtable{"phonebook"}) || fatal("Cannot open phonebook file '" . $configtable{"phonebook"} . "': $!");
	while( defined($confline = <PHONEBFILE>)) {
		chomp($confline);
		if($confline =~ /\d:.*/) {
			($confindex,$configvalue,$configcategory) = split(":",$confline);
			if($configcategory) {
				if($configcategory =~ /w|W/) {
					$whitelist{$confindex} = 1;
				} elsif ($configcategory =~ /b|B/) {
					$blacklist{$confindex} = 1;
				} else {
					print "\nWARNING: Unrecognized category '$configcategory' for $confindex ($configvalue)\n";
				}
			}
			$phonebook{$confindex} = $configvalue;
		}
	}
	close(PHONEBFILE) || fatal("Cannot close phonebook file: $!");
	printf "OK (%d entries)\n",0+keys(%phonebook);
	($log_verbose) && printf LOGFILE "Phonebook file %s read OK (%d entries)\n",$configtable{"phonebook"},0+keys(%phonebook);
	printf "  Blacklist contains %d numbers\n",0+keys(%blacklist);
	($log_verbose) && printf LOGFILE "Blacklist contains %d numbers\n",0+keys(%blacklist);
	if($configtable{"use_whitelist"}) {
		$use_whitelist = 1;
		printf "  Whitelist contains %d numbers\n",0+keys(%whitelist);
		($log_verbose) && printf LOGFILE "Whitelist contains %d numbers\n",0+keys(%whitelist);
	}
}

sub send_YAC {
	my ($message) = @_;
	my $sock;

	foreach(@yaclist) {
		$sock = new IO::Socket::INET ( 
				PeerAddr => $_,
				PeerPort => '10629', 
				Proto => 'tcp', 
				Timeout => '1',
				); 
		if ($sock) {
			print $sock $message; 
			close($sock);
		}
	} 

	# Put messages in the queue for displaying on Squeezebox.
	chomp($message);
	$queue->enqueue($message);
	#if ($message =~ /^[0-9]+$/) {
	#	my $sbmsg = "./sbmsg.sh \"$message\"";
	#	system($sbmsg);
	#}
}

sub lookup_number {
# try to look up CID number on internet
	my ($i, $j, $name, $simplePage,$result);
# This is a first draft, could be done much better...
	$result = 0;
	if($configtable{"internet_search_engine"} =~ /0|2/) {  # use hitta.se
		$simplePage=get("http://www.hitta.se/SearchMixed.aspx?vad=$cid&var=");
		if( ($i = index($simplePage,"&name=")) > 0) {   # result found
			$j = index($simplePage,";",($i+1));
			$name = substr($simplePage,($i+6),($j-$i-8));
			$result = 1;
		}
	}

	if((! $result) && ($configtable{"internet_search_engine"} =~ /1|2/)) {  # use eniro.se
		$simplePage=get("http://www.eniro.se/query?hpp=&ax=&search_word=$cid&what=web_local");
		if( ($i = index($simplePage,"<h3>Personer   1 tr&auml;ff  </h3>")) > 0) {
			$i = index($simplePage,"fileas=\"",$i) + 8;
			$j = index($simplePage,"\"",$i);
			$name = substr($simplePage,($i),($j-$i));
# fix swedish characters
			$name =~ s/&aring;/�/g;
			$name =~ s/&auml;/�/g;
			$name =~ s/&ouml;/�/g;
			$name =~ s/&Aring;/�/g;
			$name =~ s/&Auml;/�/g;
			$name =~ s/&Ouml;/�/g;
			$result = 1;
		} 
	}
	if($result) {
		$phonebook{$cid} = $name;	# Save translation for this session
			if($configtable{"save_internet_lookup"}) { # Save translation for future sessions
				if(open(PHONEBFILE,(">>" . $configtable{"phonebook"}))) {
					print PHONEBFILE "$cid:$name\n";
					close(PHONEBFILE);
				} else {
					printf "Could not open phonebook file '%s' to save number\n",$configtable{"phonebook"};
					printf LOGFILE "Could not open phonebook file '%s' to save number\n",$configtable{"phonebook"};
				}
			} 
		$cid = "$name ($cid)";
	}
	return $result;
}

sub create_logfile {
#Create the logfile

	(-w $configtable{"logdir"}) || fatal("log folder '" . $configtable{"logdir"} . "' does not exist or is not writable");
	if($configtable{"logreuse"}) {
		$logfile = $configtable{"logdir"} . (($OS_win) ?"\\":"/") . $configtable{"logbasename"} . "full.txt";
	} else {
		$logfile = $configtable{"logdir"} . (($OS_win) ?"\\":"/") . $configtable{"logbasename"}. $starttime . ".txt";	
	}
	$logfile =~ s/[ :]/_/g;
	print "$0 started at $starttime\n";
	print "Logfile is $logfile\n";
	open(LOGFILE,">>$logfile") || fatal("Cannot open logfile $logfile: $! ");
# Set file handle hot to flush each line
	select((select(LOGFILE), $|=1)[0]);	
	($log_verbose) && print LOGFILE "$0 script started at $starttime\n";
}

sub open_port {
	my ($prefix, $cleartext) = @_;
	my ($com, $port);
	$port = $configtable{$prefix . "_port"};
	if ($OS_win) {
		$com = Win32::SerialPort->new ($port);
	} else {
		$com = Device::SerialPort->new ($port);
	}
	unless ($com) { fatal("Can't open serial $cleartext port $port: $^E")};
	$com->user_msg(1);	# misc. warnings
		$com->error_msg(1);	# hardware and data errors
		$com->baudrate($configtable{$prefix . "_speed"}) || fatal( "fail setting $cleartext baud rate");
	$com->parity($configtable{$prefix . "_parity"}) || fatal( "fail setting $cleartext parity");
	$com->databits($configtable{$prefix . "_databits"}) || fatal( "fail setting $cleartext databits");
	$com->stopbits($configtable{$prefix . "_stopbits"}) || fatal( "fail setting $cleartext stopbits");
	$com->handshake($configtable{$prefix . "_handshake"}) || fatal( "fail setting $cleartext handshake");
	$com->write_settings || fatal( "no settings for $cleartext port");
	printf "Opening $cleartext connection to port $port at %s baud : OK\n",$configtable{$prefix . "_speed"};
	return $com;
}
sub test_modem_communication {
	my ($com) = @_;
	printf "Sending Modem initialization string: %s\n",write_OK($com,"AT S0=0\r");
	($log_verbose) && printf LOGFILE "Opening Modem connection at %s baud : OK\n",$configtable{"modem_speed"};
}

sub test_CID_communication {
	my ($com) = @_;
	print "Checking communication with Caller ID device: ";
	$com->write("2") || fatal("Cannot write to CallerID port");
	$answ = monitor_serial($com);
	unless ($answ =~ /.*[0-9]+/) {fatal("Bad answer from Caller ID device: '$answ'")} ;
	print "OK\n";
	($log_verbose) && printf LOGFILE "Opening CallerID connection at %s baud : OK\n",$configtable{"cid_speed"};
}

sub fatal {
	my ($message) = @_;
#...
	print "\n";
	if(defined fileno(LOGFILE)) {	
		print LOGFILE "FATAL: $message\n" ;
		close LOGFILE;	
	}
	die "\nFATAL: $message\n" ;
}


#sub get_the_time {
#	my @timeData = localtime(time);
#	# Hour and minute
#	return ($timeData[2], $timeData[1]);
#}


# Read the configuration file
# File name = same as script base name + .ini
($configname = $0) =~ s/\.pl$|\.exe$/.ini/;
read_config($configname);

create_logfile();

##$modem_ob = open_port("modem","Modem");
#test_modem_communication($modem_ob);

$numpres_ob = open_port("cid","Caller ID");
test_CID_communication($numpres_ob);

read_phonebook($configtable{"phonebook"});
if($use_nightmode) {
	init_nightmode_status();
}


print "Ready to handle incoming calls...\n";

# Main loop - running forever
while(1) {
	$answ = monitor_serial($numpres_ob);
	$is_anon = 0;
	if($answ =~ /.*A[0-9]+C.*/) {		# CID present 
		$cid = (split(/[AC]/,$answ))[1];
		if(($nightmode) && ($use_whitelist)) {
			handle_call_whitelist();
		} else {
			handle_call_normal_mode();
		}
	} elsif ($answ =~ /.*B.*C.*/) {	# CID hidden
		$is_anon = 1;
		$cid = "Anonymous (Code " . (split(/[BC]/,$answ))[1] . ")";
		if(($nightmode) && ($use_whitelist)) {
			handle_call_whitelist();
		} else {
			handle_call_normal_mode();
		}     
	} else {				# WTF?
		printf "Unexpected string received from Caller ID device: '$answ' at %s\n",get_the_time();
		printf LOGFILE "%s: Unexpected string received from Caller ID device: '$answ'\n",get_the_time();
	}
} # end of main loop

# Code never reached
undef $modem_ob;
undef $numpres_ob;
fatal("This code should never be reached until 'forever' has passed");

# end of main program
